# Kotlin
#cs/programming/kotlin

## Kotlin for Java Developers
- [[Basics]]
- [[Extension]]
- [[Nullability]]
- [[Functional Programming]]
- [[Properties]]
- [[Conventions]]
- [[Sequences]]
- [[Lambda with receiver]]
- [[Type]]

## In short
* General purpose
* OOP + Functional Programming
* Static Typing
* Open Source developed by JetBrains

## Kotlin Philosophy
* Concise
* Safe
* Interoperable
	* Use "every" java library in kotlin
* Tool-friendly

## Design Principle
* Deliberately not a research project

## History
* 2016-02 Kotlin v1.0
* 2017-11 Kotlin v1.2
* 2018-10 Kotlin v1.3
* 2019-05 Google announced that the Kotlin programming language is now its preferred language for android
* 2020-08 Kotlin v1.4 - Slight changes to the support for Apple's platforms (i.e. Objective-C/Swift interpolation)
