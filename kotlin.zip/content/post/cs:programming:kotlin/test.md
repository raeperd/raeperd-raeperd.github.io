# test
#cs/algorithm/problems #cs/programming/kotlin

1

```kotlin
class Solution {
    fun solution(table: Array<String>, languages: Array<String>, preferences: IntArray): String {
    }
}

class Job(val inputString: String) {
    val name: String
    val languages: List<String>

    init {
        val tokens = inputString.split(" ")
        name = tokens[0]
        languages = tokens.drop(1).reversed()
    }

    fun calculatePreference(languages: Array<String>, preferences: IntArray) {
    }

}

fun main() {
    println(" start !! ")
}
```

- - - -

2

```kotlin
import java.util.*
import javax.security.auth.callback.CallbackHandler

class Solution {
    fun solution(inp_str: String): IntArray {
        val answer: MutableList<Int> = mutableListOf()
        if (!inp_str.firstCheck()) {
            answer.add(1)
        }
        if (!inp_str.secondCheck()) {
            answer.add(2)
        }
        if (!inp_str.thirdCheck()) {
            answer.add(3)
        }
        if (!inp_str.forthCheck()) {
            answer.add(4)
        }
        if (!inp_str.fifthCheck()) {
            answer.add(5)
        }

        return if (answer.isEmpty()) {
            intArrayOf(0)
        } else {
            answer.toIntArray()
        }
    }

    private fun String.firstCheck(): Boolean {
        return length in 8..15
    }

    private fun String.secondCheck(): Boolean {
        return filterNot { it.isLetterOrDigit() }
            .filterNot { it in "~!@#\$%^&*" }
            .isEmpty()
    }

    private fun String.thirdCheck(): Boolean {
        var count = 0
        if (any { it in 'A'..'Z' }) {
            count += 1
        }
        if (any { it in 'a'..'z'}) {
            count += 1
        }
        if (any {it in '0'..'9'}) {
            count += 1
        }
        if (any {it in "~!@#\$%^&*"}) {
            count += 1
        }
        return 2 < count
    }

    private fun String.forthCheck(): Boolean {
        val stack: MutableList<Char> = mutableListOf('(')
        for (char in toList()) {
            if (stack.size == 4) {
                return false
            }
            if (stack.last() == char) {
                stack.add(char)
            }
            else {
                stack.removeAt(stack.lastIndex)
                stack.add(char)
            }
        }
        return true
    }

    private fun String.fifthCheck(): Boolean {
        return groupBy { it }
            .filterValues { 4 < it.size }
            .isEmpty()
    }

}
```

3

```kotlin
class Solution {
    fun solution(enter: IntArray, leave: IntArray): IntArray {
        val people = IntRange(1, enter.size)
        val enteredPeople = enter.toList()
        val leftPeople = leave.toList()

        val peopleBefore = enteredPeople.peopleBefore(1)
        val peopleAfter = leftPeople.peopleAfter(1)
        return people.map { person ->
                enteredPeople.peopleBefore(person) intersect leftPeople.peopleAfter(person)}
            .map { it.size }
            .toIntArray()
    }

    private fun List<Int>.peopleAfter(person: Int) = subList(indexOf(person), size)
    private fun List<Int>.peopleBefore(person: Int) = subList(0, indexOf(person))
}

fun main() {
    Solution().solution(intArrayOf(1, 3, 2), intArrayOf(1, 2, 3))
}
```

뒤에 온사람이 먼저 나갔나?

먼저 온사람이 나중에 나갔나?

```kotlin
class Solution {
    fun solution(program: String, flag_rules: Array<String>, commands: Array<String>): BooleanArray {
        val flagArgumentRules = flag_rules.map { FlagArgumentRule(it) }
        val structuredCommand = commands.map { Command(it, flagArgumentRules) }

        return structuredCommand.map { it.isValidCommand(program) }
            .toBooleanArray()
    }
}

class Command(commandString: String, private val rules: List<FlagArgumentRule>) {

    private val program: String
    private val arguments: List<Argument>

    init {
        val tokens = commandString.split(" ")
        program = tokens[0]
        arguments = tokens.drop(1)
            .map { Argument(it) }
    }

    fun isValidCommand(program: String): Boolean {
        return program == this.program &&
                arguments.all { argument -> rules.filter {argument.rule == it.flagRule}
                    .map { argument.validateByRule(it) }
                    .first()
                }
    }
}

class Argument(argument: String) {
    val rule: String
    private val extraArgument: String?

    init {
        val tokens = argument.split(" ")
        rule = tokens[0]
        extraArgument = if (tokens.size == 1) {
            null
        } else {
            tokens[1]
        }
    }

    fun validateByRule(flagRule: FlagArgumentRule): Boolean {
        val b = rule == flagRule.flagRule && flagRule.isValidArgument(extraArgument)
        return rule == flagRule.flagRule && flagRule.isValidArgument(extraArgument)
    }
}

class FlagArgumentRule(rule: String) {

    val flagRule: String
    private val flagArgumentType: FlagArgumentType

    init {
        val tokens = rule.split(" ")
        flagRule = tokens[0]
        flagArgumentType = FlagArgumentType.valueOf(tokens[1])
    }

    fun isValidArgument(argument: String?): Boolean {
        if (argument == null) {
            return flagArgumentType == FlagArgumentType.NULL;
        }
        return when (flagArgumentType) {
            FlagArgumentType.NUMBER -> argument.all { it.isDigit() }
            FlagArgumentType.STRING -> argument.all { it.isLetter() }
            else -> false
        }
    }
}

enum class FlagArgumentType {
    NULL, NUMBER, STRING
}

fun main() {
    val program = "line"
    val strings = arrayOf("-s STRING", "-n NUMBER", "-e NULL")
    val strings1 = arrayOf("line -n 100 -s hi -e", "lien -s Bye")
    val solution = Solution().solution(program, strings, strings1)
    println(solution[0])
    println(solution[1])
}
```

// redesigned

```kotlin
import java.lang.RuntimeException

class Solution {

    private val ruleFactory = FlagRuleFactory()

    fun solution(program: String, rawRules: Array<String>, rawCommands: Array<String>): BooleanArray {
        val commands = rawCommands.map { Command(it) }
        val predefinedRuleMap = rawRules.map { rule -> rule.split(" ") }
            .map { token -> token[0] to token[1] }
            .toMap()
            .mapValues { ruleFactory.build(it.value) }

        return commands.map { command -> command.program == program && command.argumentRuleMap.isNotEmpty() &&
            command.argumentRuleMap.all { (key, value) ->
                predefinedRuleMap[key]?.isValidArgument(value) ?: false
            }
        }.toBooleanArray()
    }
}

class Command(command: String) {

    val program: String
    val argumentRuleMap: Map<String, String?>

    init {
        val commandTokens = command.split(" ")
        program = commandTokens[0]
        argumentRuleMap = commandTokens.drop(1).zipWithNext()
            .filter { (key, _ ) -> key.startsWith("-") }
            .toMap()
    }
}

class FlagRuleFactory {

    fun build(type: String): FlagRule {
        return when(type) {
            "STRING" -> StringFlagRule()
            "NUMBER" -> NumberFlagRule()
            "NULL" -> NullFlagRule()
            else -> throw RuntimeException()
        }
    }
}

interface FlagRule {
    fun isValidArgument(argument: String?): Boolean;
}

class StringFlagRule : FlagRule {
    override fun isValidArgument(argument: String?): Boolean {
        return argument?.all { it.isLetter() } ?: false
    }
}

class NumberFlagRule : FlagRule {
    override fun isValidArgument(argument: String?): Boolean {
        return argument?.all { it.isDigit() } ?: false
    }
}

class NullFlagRule : FlagRule {
    override fun isValidArgument(argument: String?): Boolean {
        return argument == null
    }
}
```
