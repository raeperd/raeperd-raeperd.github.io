# TaxiPark
#cs/algorithm/problems #cs/programming/kotlin

## Taxi Park
The `TaxiPark` class stores information about registered drivers, passengers, and their trips. Your task is to implement six functions which collect different statistics about the data.

#### Task 1
```kotlin
fun TaxiPark.findFakeDrivers(): Collection<Driver>
```
Find all the drivers who didn't perform any trips.

#### Task 2
```kotlin
fun TaxiPark.findFaithfulPassengers(minTrips: Int): List<Passenger>
```
Find all the clients who completed at least the given number of trips.

#### Task 3
```kotlin
fun TaxiPark.findFrequentPassengers(driver: Driver): List<Passenger>
```
Find all the passengers who were driven by a certain driver more than once.

#### Task 4
```kotlin
fun TaxiPark.findSmartPassengers(): Collection<Passenger>
```
If we consider "smart", a passenger who had a discount for the majority of the trips they made or took part in (including the trips with more than one passenger), find all the "smart" passengers. A "smart" passenger should have strictly more trips with discount than trips without discount, the equal amounts of trips with and without discount isn't enough.

Note that the discount can't be0.0, it's always non-zero if it's recorded.

#### Task 5
```kotlin
fun TaxiPark.findTheMostFrequentTripDurationPeriod(): IntRange?
```
Find the most frequent trip duration period among minute periods 0..9, 10..19, 20..29, and so on. Return any suitable period if many are the most frequent, return `null` if there're no trips.

#### Task 6
```kotlin
fun TaxiPark.checkParetoPrinciple(): Boolean
```

Check whether no more than 20% of the drivers contribute 80% of the income. The function should return true if the top 20% drivers (meaning the top 20% best performers) represent 80% or more of all trips total income, or false if not. The drivers that have no trips should be considered as contributing zero income. If the taxi park contains no trips, the result should be false.

For example, if there're 39 drivers in the taxi park, we need to check that no more than 20% of the most successful ones, which is seven drivers (39 * 0.2 = 7.8), contribute at least 80% of the total income. Note that eight drivers out of 39 is 20.51% which is more than 20%, so we check the income of seven the most successful drivers.

To find the total income sum up all the trip costs. Note that the discount is already applied while calculating the cost.

## Solution
### Task 1
```kotlin
/*
 * Task #1. Find all the drivers who performed no trips.
 */
fun TaxiPark.findFakeDrivers(): Set<Driver> =  allDrivers.minus(trips.map { it.driver })
```

### Task 2
```kotlin
/*
 * Task #2. Find all the clients who completed at least the given number of trips.
 */
fun TaxiPark.findFaithfulPassengers(minTrips: Int): Set<Passenger> {
        val flattenPassenger = trips.flatMap { it.passengers }
        return allPassengers.filter { minTrips <= flattenPassenger.count { passenger -> it == passenger }}.toSet()
}
```
* starts with trip or starts with passengers

#### Better way
```kotlin
// starts with trip
fun TaxiPark.findFaithfulPassengers(minTrips: Int): Set<Passenger> = 
	trips.flatMap(Trip::passengers)
		.groupBy { passenger -> passenger }
		.filterValues { group -> minTrips <= group.size }
		.keys

// starts with passengers
fun TaxiPark.findFaithfulPassengers(minTrips: Int): Set<Passenger> = 
	allPassengers.filter { paasenger ->
                         	trips.count { passenger in it.passengers } <= minTrips }
				.toSet()
```
* Method reference is better than lambda

### Task 3
```kotlin
/*
 * Task #3. Find all the passengers, who were taken by a given driver more than once.
 */
fun TaxiPark.findFrequentPassengers(driver: Driver): Set<Passenger> {
    val flattenPassengerByDriver = trips.flatMap { if (it.driver == driver) it.passengers else emptySet() }
    return allPassengers.filter { 1 < flattenPassengerByDriver.count { passenger -> it == passenger }}.toSet()
}
```

#### Better way
```kotlin
fun TaxiPark.findFrequentPassengers(driver: Driver): Set<Passenger> = 
	trips.filter { trip -> trip.driver == driver }
		.flatMap(Trip::passengers)
		.groupBy { passenger -> passenger }
		.filterValue { group -> 1 < group.size }
		.keys

fun TaxiPark.findFrequentPassengers(driver: Driver): Set<Passenger> = 
	allPassengers.filter { passenger -> 
                         	1 < trips.count { it.driver == driver && paseenger in it.passengers }
                 .toSet()
}
```

### Task 4
```kotlin
/*
 * Task #4. Find the passengers who had a discount for majority of their trips.
 */
fun TaxiPark.findSmartPassengers(): Set<Passenger> {
    val (notDiscountedTrips, discountedTrips) = trips.partition { it.discount == null }
    return allPassengers.filter { notDiscountedTrips.countPassenger(it) < discountedTrips.countPassenger(it)}
        .toSet()
}

fun List<Trip>.countPassenger(passenger: Passenger): Int = count { passenger in it.passengers }
```
* always distruct `Pair`
* `in` is better than `contains`
* `it` -> explicit lambda function -> `filter` -> `filterValues`
* when key is unique, prefer `assoiciateBy` to `groupBy`

![](TaxiPark/groupBy-vs-associateBy.jpg)groupBy-vs-associateBy

### Task 5
```kotlin
/*
 * Task #5. Find the most frequent trip duration among minute periods 0..9, 10..19, 20..29, and so on.
 * Return any period if many are the most frequent, return `null` if there're no trips.
 */

fun TaxiPark.findTheMostFrequentTripDurationPeriod(): IntRange? =
    trips.groupBy { it.duration.toDecimalIntRange() }
        .maxByOrNull { it.value.size }
        ?.key

fun Int.toDecimalIntRange(): IntRange = div(10).times(10) until div(10).plus(1).times(10)
```

### Task 6
```kotlin
/*
* Task #6.
* Check whether 20% of the drivers contribute 80% of the income.
*/
fun TaxiPark.checkParetoPrinciple(): Boolean {
    val income = trips.sumByDouble { it.cost }
    if (income == 0.0) {
        return false
    }
    val bestDrivers = allDrivers.sortedByDescending { calculateIncomeFromDriver(it) }
        .take((allDrivers.size * 0.2).toInt())
    return income * 0.8 <= trips.filter { it.driver in bestDrivers }
        .sumByDouble { it.cost }
}

fun TaxiPark.calculateIncomeFromDriver(driver: Driver): Double =
    trips.filter { it.driver == driver }
        .sumByDouble { it.cost }
```